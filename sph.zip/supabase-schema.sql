-- ==============================================================================
-- SINHGAD PLACEMENT HUB (SPH) - SUPABASE DATABASE SCHEMA
-- Run this in your Supabase SQL Editor (https://supabase.com/dashboard)
-- ==============================================================================

-- 1. PROFILES TABLE (User information, PRN, branch, role)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  prn TEXT UNIQUE,
  role TEXT DEFAULT 'student',
  branch TEXT,
  graduation_year TEXT,
  company TEXT,
  job_role TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles Policies
CREATE POLICY "Public profiles are viewable by everyone" 
ON public.profiles FOR SELECT 
USING (true);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id);

-- 2. EXPERIENCES TABLE (Interview experiences shared by students & alumni)
CREATE TABLE IF NOT EXISTS public.experiences (
  id TEXT PRIMARY KEY,
  company TEXT NOT NULL,
  company_logo TEXT,
  role TEXT NOT NULL,
  status TEXT NOT NULL,
  year TEXT DEFAULT '2024',
  rounds_count INTEGER DEFAULT 3,
  review TEXT NOT NULL,
  tags TEXT[] DEFAULT '{}',
  author_name TEXT DEFAULT 'Anonymous',
  author_branch TEXT DEFAULT 'Computer Engineering',
  author_batch TEXT DEFAULT 'Batch 2024',
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  likes INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for experiences
ALTER TABLE public.experiences ENABLE ROW LEVEL SECURITY;

-- Experiences Policies
CREATE POLICY "Anyone can read experiences" 
ON public.experiences FOR SELECT 
USING (true);

CREATE POLICY "Anyone authenticated can create experiences" 
ON public.experiences FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update their own experiences or likes" 
ON public.experiences FOR UPDATE 
USING (true);

-- 3. QUESTIONS / DOUBTS TABLE (Community Q&A)
CREATE TABLE IF NOT EXISTS public.questions (
  id TEXT PRIMARY KEY,
  question_text TEXT NOT NULL,
  company TEXT,
  author_name TEXT DEFAULT 'Anonymous',
  author_branch TEXT DEFAULT 'Computer Engineering',
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  upvotes INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for questions
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read questions" 
ON public.questions FOR SELECT 
USING (true);

CREATE POLICY "Anyone can submit questions" 
ON public.questions FOR INSERT 
WITH CHECK (true);

-- ==============================================================================
-- INITIAL SAMPLE DATA (Optional: Insert some sample experiences)
-- ==============================================================================

INSERT INTO public.experiences (id, company, company_logo, role, status, year, rounds_count, review, tags, author_name, author_branch, author_batch, likes, comments_count)
VALUES 
  ('exp-1', 'TCS', 'tcs', 'Software Developer', 'Selected', '2024', 3, 'Aptitude was moderate, technical round focused on DSA and OOP. HR was friendly.', ARRAY['DSA', 'OOP', 'Aptitude'], 'Aarav Patil', 'Computer Engineering', 'Batch 2024', 24, 5),
  ('exp-2', 'Infosys', 'infosys', 'Specialist Programmer', 'Selected', '2024', 4, 'HackWithInfy route: 2 coding questions on dynamic programming. Interview tested system design and SQL joins.', ARRAY['DP', 'SQL', 'HackWithInfy'], 'Rohan Deshmukh', 'IT', 'Batch 2024', 31, 8),
  ('exp-3', 'Accenture', 'accenture', 'Associate Software Engineer', 'Selected', '2024', 3, 'Cognitive and tech assessment was key. Technical interview asked basics of cloud and web development.', ARRAY['Cloud', 'Web', 'Cognitive'], 'Sneha Kulkarni', 'AIDS', 'Batch 2024', 19, 3)
ON CONFLICT (id) DO NOTHING;
