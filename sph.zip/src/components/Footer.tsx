import { useState, type FormEvent } from "react";
import { GraduationCap } from "lucide-react";
import type { NavTab } from "./Navbar";

interface FooterProps {
  onNavigate?: (tab: NavTab) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [subscribedToast, setSubscribedToast] = useState(false);

  const handleNewsletterSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setSubscribedToast(true);
    setTimeout(() => {
      setSubscribedToast(false);
      setNewsletterEmail("");
    }, 3000);
  };

  const navLinks: { label: string; tab: NavTab }[] = [
    { label: "Home", tab: "home" },
    { label: "Experiences", tab: "experiences" },
    { label: "Companies", tab: "companies" },
    { label: "Ask & Share", tab: "ask-share" },
    { label: "Insights", tab: "insights" },
    { label: "About", tab: "about" },
  ];

  return (
    <footer className="bg-[#121924] border-t border-[#2d3c52] text-[#faf7f0] pt-14 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-[#243144]">
          {/* Col 1: Brand & About (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <button
              onClick={() => {
                onNavigate?.("home");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="flex items-center gap-3 text-left hover:opacity-90 transition cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-[#1a2332] border border-[#c9a961]/40 flex items-center justify-center shadow-md">
                <GraduationCap className="w-5 h-5 text-[#c9a961]" />
              </div>
              <div>
                <p className="font-bold text-[#faf7f0] text-base">
                  Sinhgad Placement Hub
                </p>
                <p className="text-xs text-[#c9a961] font-medium">
                  Learn · Share · Grow Together
                </p>
              </div>
            </button>

            <p className="text-xs sm:text-sm text-amber-100/75 leading-relaxed">
              A student-driven platform to collect, share and learn from
              placement experiences within the Sinhgad community.
            </p>

            {/* Social links */}
            <div className="flex items-center gap-3 pt-2">
              {["LinkedIn", "Instagram", "YouTube", "X"].map((net) => (
                <button
                  key={net}
                  className="w-8 h-8 rounded-lg bg-[#1a2332] border border-[#2e3c50] text-amber-100/70 hover:text-[#c9a961] hover:border-[#c9a961]/60 flex items-center justify-center text-xs font-bold transition-all cursor-pointer"
                  title={net}
                >
                  {net[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Col 2: Quick Links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <p className="text-sm font-bold text-[#c9a961] tracking-wider uppercase">
              Quick Links
            </p>
            <ul className="space-y-2 text-xs sm:text-sm text-amber-100/80">
              {navLinks.map((item) => (
                <li key={item.tab}>
                  <button
                    onClick={() => {
                      if (onNavigate) {
                        onNavigate(item.tab);
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }
                    }}
                    className="hover:text-[#c9a961] transition-colors cursor-pointer"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Resources (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <p className="text-sm font-bold text-[#c9a961] tracking-wider uppercase">
              Resources
            </p>
            <ul className="space-y-2 text-xs sm:text-sm text-amber-100/80">
              {[
                { title: "Placement Preparation Tips", tab: "insights" as NavTab },
                { title: "Interview Experiences", tab: "experiences" as NavTab },
                { title: "Partner Companies", tab: "companies" as NavTab },
                { title: "Student Discussions", tab: "ask-share" as NavTab },
                { title: "About Sinhgad Hub", tab: "about" as NavTab },
              ].map((res) => (
                <li key={res.title}>
                  <button
                    onClick={() => {
                      if (onNavigate) {
                        onNavigate(res.tab);
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }
                    }}
                    className="hover:text-[#c9a961] transition-colors cursor-pointer text-left"
                  >
                    {res.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Stay Updated Newsletter (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <p className="text-sm font-bold text-[#c9a961] tracking-wider uppercase">
              Stay Updated
            </p>
            <p className="text-xs text-amber-100/75 leading-relaxed">
              Subscribe to get the latest updates and placement insights.
            </p>

            <form onSubmit={handleNewsletterSubmit} className="pt-1">
              <div className="flex flex-col gap-2">
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full rounded-xl bg-[#1a2332] border border-[#2e3c50] px-3.5 py-2 text-xs sm:text-sm text-[#faf7f0] placeholder:text-amber-100/40 focus:outline-none focus:border-[#c9a961]"
                />
                <button
                  type="submit"
                  className="w-full rounded-xl bg-[#c9a961] py-2 px-4 text-xs sm:text-sm font-bold text-[#1a2332] hover:bg-[#d8b86e] active:scale-95 transition-all shadow-md cursor-pointer"
                >
                  Subscribe
                </button>
              </div>
              {subscribedToast && (
                <p className="text-[11px] text-emerald-400 mt-2 font-medium">
                  ✓ Subscribed! You will receive new placement updates.
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Bottom copyright row */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-amber-100/60">
          <p>© 2024 Sinhgad Placement Hub. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Made with <span className="text-rose-400">❤️</span> for the Sinhgad Community
          </p>
        </div>
      </div>
    </footer>
  );
}
