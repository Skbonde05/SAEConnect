import React, { useState, useEffect } from "react";
import SplashScreen from "./components/SplashScreen";
import Login from "./components/Login";
import Register from "./components/Register";
import ResetPassword from "./components/ResetPassword";
import HomeDashboard from "./components/HomeDashboard";
import {
  getCurrentUser,
  signInUser,
  signUpUser,
  signOutUser,
  isRecoveryFlow,
  type UserProfile,
} from "./lib/supabase";
import "./index.css";

type Screen = "splash" | "login" | "register" | "home" | "reset-password";

function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // ✅ Track email that needs verification after signup
  const [verifyEmailSentTo, setVerifyEmailSentTo] = useState<string | null>(
    null
  );

  /* =====================================================
     DETECT RECOVERY LINK ON MOUNT

     If the user arrived from a Supabase password-reset
     email, the URL will contain `#access_token=...&type=recovery`.
     Route them to the reset-password screen instead of
     the splash/login flow.
  ===================================================== */
  useEffect(() => {
    if (isRecoveryFlow()) {
      setScreen("reset-password");
    }
  }, []);

  /* =====================================================
     CHECK INITIAL AUTHENTICATION STATE ON APP LOAD
  ===================================================== */
  useEffect(() => {
    let isMounted = true;

    async function checkAuth() {
      // Don't override the reset-password route
      if (isRecoveryFlow()) return;

      try {
        const user = await getCurrentUser();
        if (isMounted && user) {
          setCurrentUser(user);
          setIsLoggedIn(true);
        }
      } catch (err) {
        console.warn("Error checking initial auth session:", err);
      }
    }

    checkAuth();

    return () => {
      isMounted = false;
    };
  }, []);

  /* =====================================================
     SPLASH SCREEN NAVIGATION
     - If already logged in -> open HomeDashboard after SplashScreen
     - If not logged in -> open Login page after SplashScreen
  ===================================================== */
  const handleSplashFinish = () => {
    if (isLoggedIn) {
      setScreen("home");
    } else {
      setScreen("login");
    }
  };

  /* =====================================================
     LOGIN HANDLER (Supabase Auth)
  ===================================================== */
  const handleLogin = async (emailOrPrn: string, password: string) => {
    setAuthLoading(true);
    setAuthError(null);

    const { user, error } = await signInUser(emailOrPrn, password);

    setAuthLoading(false);

    if (error || !user) {
      setAuthError(error || "Invalid credentials. Please try again.");
      return;
    }

    setCurrentUser(user);
    setIsLoggedIn(true);
    setAuthError(null);
    setScreen("home");
  };

  /* =====================================================
     REGISTER HANDLER (Supabase Auth + Database Profile)

     IMPORTANT:
     - If Supabase returns a user but NO session, it means
       email confirmation is required. In that case we must
       NOT log the user in — we show a "verify your email"
       success screen instead.
     - The sentinel string "ACCOUNT_CREATED_VERIFY_EMAIL"
       is what signUpUser() returns in that scenario.
  ===================================================== */
  const handleRegister = async (data: {
    fullName: string;
    email: string;
    password: string;
    role: string;
    branch: string;
    year?: string;
    graduationYear?: string;
    prn?: string;
    designation?: string;
    employeeId?: string;
    officialEmail?: string;
    company?: string;
    jobRole?: string;
    industry?: string;
    linkedin?: string;
  }) => {
    setAuthLoading(true);
    setAuthError(null);
    setVerifyEmailSentTo(null);

    const { user, error } = await signUpUser(data);

    setAuthLoading(false);

    /* --------------------------------------------------
       Case 1: Email verification required
       Supabase created the user but no session yet.
    -------------------------------------------------- */
    if (error === "ACCOUNT_CREATED_VERIFY_EMAIL") {
      setVerifyEmailSentTo(data.email);
      return; // ❌ do NOT setIsLoggedIn(true) here
    }

    /* --------------------------------------------------
       Case 2: Any other error
    -------------------------------------------------- */
    if (error || !user) {
      setAuthError(error || "Registration failed. Please check your details.");
      return;
    }

    /* --------------------------------------------------
       Case 3: Successful signup WITH session
       (only happens when email confirmation is OFF)
    -------------------------------------------------- */
    setCurrentUser(user);
    setIsLoggedIn(true);
    setAuthError(null);
    setScreen("home");
  };

  /* =====================================================
     LOGOUT HANDLER
  ===================================================== */
  const handleLogout = async () => {
    await signOutUser();
    setCurrentUser(null);
    setIsLoggedIn(false);
    setScreen("login");
  };

  /* =====================================================
     SPLASH SCREEN
  ===================================================== */
  if (screen === "splash") {
    return (
      <SplashScreen
        duration={4500}
        onFinish={handleSplashFinish}
        onGetStarted={handleSplashFinish}
        onLogin={() => {
          if (isLoggedIn) {
            setScreen("home");
          } else {
            setScreen("login");
          }
        }}
      />
    );
  }

  /* =====================================================
     LOGIN PAGE
  ===================================================== */
  if (screen === "login") {
    return (
      <Login
        errorMessage={authError}
        isLoading={authLoading}
        onCreateAccount={() => {
          setAuthError(null);
          setVerifyEmailSentTo(null);
          setScreen("register");
        }}
        onLogin={handleLogin}
      />
    );
  }

  /* =====================================================
     REGISTER PAGE
  ===================================================== */
  if (screen === "register") {
    return (
      <Register
        errorMessage={authError}
        isLoading={authLoading}
        verifyEmailSentTo={verifyEmailSentTo}
        onLogin={() => {
          setAuthError(null);
          setVerifyEmailSentTo(null);
          setScreen("login");
        }}
        onRegister={handleRegister}
      />
    );
  }

  /* =====================================================
     RESET PASSWORD PAGE
     Rendered when Supabase redirects the user back from
     a password-reset email (#type=recovery in the URL).
  ===================================================== */
  if (screen === "reset-password") {
    return (
      <ResetPassword
        onDone={() => {
          setAuthError(null);
          setVerifyEmailSentTo(null);
          setIsLoggedIn(false);
          setCurrentUser(null);
          setScreen("login");
        }}
      />
    );
  }

  /* =====================================================
     HOME DASHBOARD
  ===================================================== */
  return (
    <ErrorBoundary>
      <HomeDashboard
        user={currentUser}
        onLogout={handleLogout}
        onOpenLogin={() => setScreen("login")}
        onOpenRegister={() => setScreen("register")}
      />
    </ErrorBoundary>
  );
}

/* =====================================================
   ERROR BOUNDARY
===================================================== */
class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error: Error | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#1a2332] text-[#faf7f0] p-10 font-sans flex items-center justify-center">
          <div className="max-w-xl w-full bg-[#202b3c] border border-[#2e3c50] rounded-2xl p-8 shadow-2xl">
            <h2 className="text-[#c9a961] text-2xl font-bold mb-3">
              Sinhgad Placement Hub - Something went wrong
            </h2>
            <p className="text-amber-100/90 text-sm mb-4 leading-relaxed">
              {this.state.error?.message ||
                "An unexpected error occurred while rendering the page."}
            </p>
            <pre className="bg-[#141c28] p-4 rounded-xl text-rose-400 text-xs overflow-x-auto mb-6 max-h-48">
              {this.state.error?.stack}
            </pre>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-2.5 bg-[#c9a961] text-[#1a2332] font-bold rounded-xl hover:bg-[#d9b971] transition shadow-md cursor-pointer"
            >
              Reload Platform
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default App;